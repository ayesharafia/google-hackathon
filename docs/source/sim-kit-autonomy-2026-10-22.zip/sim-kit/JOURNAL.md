# JOURNAL.md : What agents did and why (newest first)

Each entry:
```
## <date> <task id> : <title>
Plan: why this task now, done-means, zone
Result: numbers, pass/fail
Changed: files
Parked/Inbox: anything added
```
