# INBOX_FOR_SCIENTIST.md

Keep this short. Every item must be answerable in under 5 minutes. Max 3 open specs.

| # | Item (spec / failed validation / tolerance) | Link | Question (yes/no or pick one) | Waiting since | Answer |
|---|---|---|---|---|---|
