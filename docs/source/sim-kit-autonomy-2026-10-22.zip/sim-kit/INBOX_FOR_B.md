# INBOX_FOR_B.md

B: answer inline with one word (yes / no / later) or write a direction. Agents read this every run.

## Decisions waiting
| # | Question | Agent's recommendation | Default if no answer in 3 days | B's answer |
|---|---|---|---|---|

## Direction from B (optional, write anything here)
-
