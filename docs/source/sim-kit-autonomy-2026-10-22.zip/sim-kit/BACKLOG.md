# BACKLOG.md : Ready-to-pick tasks (maintained by agents)

Priority of domains (B sets this, agents follow): 1. ?  2. ?  3. ?  4. ?

| ID | Task | Domain | Zone | Done means (a number) | Blocked by | Status |
|---|---|---|---|---|---|---|
| T001 | Build validation harness: run case, compare to reference, save overlay plot | shared | 🟢 | Harness runs 1D conduction exact case with error < 1e-6 on trivial mesh | none | ready |
| T002 | Conservation checker (mass, energy, charge) usable by all solvers | shared | 🟢 | Reports imbalance % on any run | T001 | ready |
| T003 | Mesh convergence / GCI tool (Roache) | shared | 🟢 | Reproduces a textbook GCI example | T001 | ready |
| T004 | Audit each domain's existing code, assign proven ladder levels | all | 🟢 | ROADMAP.md fully filled | none | ready |
| T005 | Central constants config with citations; flag every uncited number in code | shared | 🟢 | List of uncited constants = 0 or all marked UNVERIFIED | none | ready |
