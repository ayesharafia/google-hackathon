# DECISIONS.md : Every assumption, change, and approval

Append only. Never edit old entries.

| # | Date | Feature | Decision / change | Why | Proposed by | Approved by |
|---|---|---|---|---|---|---|
| 001 | | all | Adopt V&V ladder in VALIDATION.md as ship gate | Industry practice (ASME V&V 20) | B | |
