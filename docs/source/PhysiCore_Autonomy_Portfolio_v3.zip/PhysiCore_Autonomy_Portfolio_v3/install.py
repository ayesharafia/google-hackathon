#!/usr/bin/env python3
"""Safely install a portable, dependency-free PhysiCore harness in multiple repositories.

This script never commits, pushes, deploys, downloads packages or runs application code.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile

BASE = Path(__file__).resolve().parent
SRC = BASE / 'assets' / 'repo'
EXCLUDED = {'.git', 'node_modules', '.venv', 'venv', '.tox', 'dist', 'build', '__pycache__', '.next', '.cache'}
DYNAMIC = {
    '.physicore/ops/TASKS.json', '.physicore/ops/STATE.md',
    '.physicore/ops/WORKLOG.md', '.physicore/ops/APPROVALS.md',
    '.physicore/ops/RESEARCH_LOG.md', '.physicore/ops/INVESTOR_DIGEST.md',
    '.physicore/ops/STRATEGY.md',
}
START = '<!-- PHYSICORE AUTONOMY V3 START -->'
END = '<!-- PHYSICORE AUTONOMY V3 END -->'
RULES = '''<!-- PHYSICORE AUTONOMY V3 START -->
## PhysiCore autonomous project work
When given an actual task, perform that task using the relevant repo context. When the user says only "work", "continue", "build", or "keep going", follow `.physicore/ops/WORKFLOW.md`: inspect `.physicore/ops/STATE.md`, choose an eligible evidenced task using `python3 .physicore/tools/workflow.py next`, implement one meaningful safe slice, verify it, and persist the result. Treat project code and existing repository rules as authoritative. Never infer physical validity from passing code tests. Do not merge, deploy, spend money, message people, or make safety-critical changes without explicit authorization. Keep existing narrower safety and domain rules; use `.physicore/AGENT_POLICY.md` for extended operating guidance. If this kit conflicts with an existing policy, preserve the stricter boundary and report the conflict. Never claim to operate when no tool session is active.
<!-- PHYSICORE AUTONOMY V3 END -->'''

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write_atomic(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.pc-', suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(content)
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)

def secure_destination(repo: Path, rel: Path) -> Path:
    if rel.is_absolute() or '..' in rel.parts: raise ValueError('Unsafe relative path')
    dst = repo / rel
    for candidate in (repo, *list(dst.parents)[::-1], dst):
        if candidate.exists() and candidate.is_symlink(): raise ValueError(f'Symlink destination forbidden: {candidate}')
    if not dst.resolve().is_relative_to(repo.resolve()): raise ValueError('Path escapes repository')
    return dst

def scan_repos(root: Path, max_depth: int=4) -> list[Path]:
    root = root.resolve()
    found=[]
    if not root.is_dir(): return found
    for directory, dirs, files in os.walk(root, followlinks=False):
        p=Path(directory)
        depth=len(p.relative_to(root).parts)
        is_repo = (p/'.git').is_dir() or '.git' in files
        dirs[:] = [d for d in sorted(dirs) if d not in EXCLUDED and not (p/d).is_symlink()] if depth < max_depth else []
        if is_repo:
            found.append(p)
            dirs[:] = []
    return found

def reconcile_agents(repo: Path, dry: bool, changes: list[str]) -> None:
    f=secure_destination(repo,Path('AGENTS.md'))
    if not f.exists():
        if not dry: write_atomic(f, ('# Repository instructions\n\n'+RULES+'\n').encode())
        changes.append('CREATE AGENTS.md (minimal bridge)')
        return
    original=f.read_text(encoding='utf-8')
    starts=original.count(START); ends=original.count(END)
    if starts!=ends or starts>1:
        changes.append('CONFLICT AGENTS.md: duplicate/broken managed markers, unchanged')
        return
    if starts:
        revised=re.sub(re.escape(START)+r'.*?'+re.escape(END),RULES,original,flags=re.S)
    else:
        revised=original.rstrip()+'\n\n'+RULES+'\n'
    if revised!=original:
        if not dry: write_atomic(f,revised.encode())
        changes.append('MERGE AGENTS.md (preserved existing rules)')
    else: changes.append('KEEP AGENTS.md (already configured)')

def install_repo(repo: Path,dry: bool=False) -> list[str]:
    repo=repo.resolve()
    if not repo.is_dir() or not (repo/'.git').exists():
        raise ValueError(f'Expected a local Git repository: {repo}')
    manifest_file=secure_destination(repo,Path('.physicore/installed.json'))
    previous={}
    if manifest_file.exists():
        try: previous=json.loads(manifest_file.read_text()).get('managed_sha256',{})
        except Exception as e: raise ValueError('Corrupt managed manifest; refusing overwrite') from e
    current=dict(previous)
    changes=[]
    for source in sorted(SRC.rglob('*')):
        if not source.is_file() or source.name=='.DS_Store' or '__pycache__' in source.parts or source.suffix=='.pyc': continue
        rel=source.relative_to(SRC)
        if rel.as_posix().endswith('AGENTS.md') and rel.parts[0] != '.agents': pass
        dest=secure_destination(repo,rel)
        data=source.read_bytes()
        key=rel.as_posix()
        if not dest.exists():
            if not dry: write_atomic(dest,data)
            current[key]=sha(data)
            changes.append('CREATE '+key)
        elif dest.is_file() and dest.read_bytes()==data:
            current[key]=sha(data)
            changes.append('KEEP '+key)
        elif key in DYNAMIC:
            changes.append('PRESERVE working memory '+key)
        elif key in previous and sha(dest.read_bytes())==previous[key]:
            if not dry: write_atomic(dest,data)
            current[key]=sha(data)
            changes.append('UPDATE managed '+key)
        else:
            changes.append('CONFLICT modified/unmanaged '+key+' (not overwritten)')
    # Preserve earlier v2 working memory as an archive if present. Never parse it
    # into the new v3 queue automatically because the schema and evidence differ.
    for old_rel in ('ops/STATE.md','ops/TASKS.json','ops/WORKLOG.md',
                    'ops/APPROVALS.md','ops/STRATEGY.md'):
        old=secure_destination(repo,Path(old_rel))
        if old.is_file() and not old.is_symlink():
            dest=secure_destination(repo,Path('.physicore/legacy')/Path(old_rel).name)
            if not dest.exists():
                if not dry:write_atomic(dest,old.read_bytes())
                changes.append('ARCHIVE v2 working memory '+old_rel+' -> '+str(dest.relative_to(repo)))
    reconcile_agents(repo,dry,changes)
    if not dry:
        write_atomic(manifest_file,(json.dumps({'package':'PhysiCore Autonomy Portfolio','version':'3.0','managed_sha256':current},indent=2,sort_keys=True)+'\n').encode())
    return changes

def install_hq(root: Path, repos:list[Path], dry:bool=False)->list[str]:
    if (root/'.git').exists(): raise ValueError('HQ workspace cannot be a source repository; use its parent directory')
    changes=[]
    out=secure_destination(root,Path('.physicore-hq/PORTFOLIO.json'))
    old={}
    if out.is_file():
        try: old=json.loads(out.read_text())
        except Exception as e: raise ValueError('Invalid existing HQ portfolio JSON') from e
    bypath={str(x['path']):x for x in old.get('projects',[]) if isinstance(x,dict) and 'path' in x}
    entries=[]
    for repo in repos:
        location=os.path.relpath(repo,root)
        entry=bypath.get(location,{'path':location,'name':repo.name,'priority':3,'customer_goal':'UNKNOWN','last_verified':'UNKNOWN','domain':'UNKNOWN','owner':'UNKNOWN'})
        entries.append(entry)
    combined={'schema_version':1,'projects':entries}
    if not dry: write_atomic(out,(json.dumps(combined,indent=2)+'\n').encode())
    changes.append('UPDATE .physicore-hq/PORTFOLIO.json (preserving existing project fields)')
    for source in sorted((BASE/'assets/hq').rglob('*')):
        if not source.is_file():continue
        rel=source.relative_to(BASE/'assets/hq')
        if rel.as_posix()=='.physicore-hq/PORTFOLIO.json':continue
        dest=secure_destination(root,rel)
        if not dest.exists():
            if not dry: write_atomic(dest,source.read_bytes())
            changes.append('CREATE '+rel.as_posix())
        elif dest.read_bytes()!=source.read_bytes():
            changes.append('PRESERVE existing '+rel.as_posix())
    f=secure_destination(root,Path('AGENTS.md'))
    hq_rules='''\n\n<!-- PHYSICORE PORTFOLIO HQ V3 START -->
## PhysiCore portfolio CEO workflow
For bare "work" or "continue", inspect `.physicore-hq/PORTFOLIO.json`, run `python3 .physicore-hq/portfolio.py status`, choose the highest-value accessible project based on evidence rather than guesswork, then follow that project's `AGENTS.md` and `.physicore/ops/WORKFLOW.md`. Respect specific user requests, project-level domain rules, approvals and scope limits. You cannot access repositories that have not been mounted/connected. Execute at most one bounded project task per session by default. Persist changes locally and report exact evidence. No automatic pushes, merges, deployments, purchases or contacting people.
<!-- PHYSICORE PORTFOLIO HQ V3 END -->\n'''
    if not f.exists():
        if not dry:write_atomic(f,('# PhysiCore portfolio workspace\n'+hq_rules).encode())
        changes.append('CREATE HQ AGENTS.md')
    else:
        text=f.read_text()
        start='<!-- PHYSICORE PORTFOLIO HQ V3 START -->';end='<!-- PHYSICORE PORTFOLIO HQ V3 END -->'
        if text.count(start)==1 and text.count(end)==1:
            updated=text[:text.index(start)]+hq_rules.strip()+text[text.index(end)+len(end):]
        elif start not in text and end not in text:
            updated=text.rstrip()+hq_rules
        else: updated=None
        if updated is None: changes.append('CONFLICT HQ AGENTS markers')
        elif updated!=text:
            if not dry:write_atomic(f,updated.encode())
            changes.append('MERGE HQ AGENTS.md')
        else:changes.append('KEEP HQ AGENTS.md')
    return changes

def main(argv=None) -> int:
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    scan=sub.add_parser('scan');scan.add_argument('--workspace',required=True);scan.add_argument('--max-depth',type=int,default=4)
    ins=sub.add_parser('install');ins.add_argument('--workspace',required=True);ins.add_argument('--all',action='store_true',help='Install to every repository inside a dedicated PhysiCore workspace');ins.add_argument('--repo',action='append',default=[],help='Explicit repository path (may repeat)');ins.add_argument('--hq',action='store_true');ins.add_argument('--dry-run',action='store_true');ins.add_argument('--max-depth',type=int,default=4)
    a=p.parse_args(argv)
    root=Path(a.workspace).expanduser().resolve()
    if not root.is_dir():p.error('Workspace path must exist')
    if a.command=='scan':
        found=scan_repos(root,a.max_depth)
        for repo in found: print('FOUND',repo)
        print('TOTAL',len(found))
        return 0
    if not a.all and not a.repo:p.error('Choose --all for a dedicated workspace, or one or more --repo paths')
    try:
        repos=[Path(x).expanduser().resolve() for x in a.repo]
        if a.all: repos+=scan_repos(root,a.max_depth)
        repos=sorted(set(repos))
        if not repos:raise ValueError('No repositories found; nothing installed')
        for repo in repos:
            print('\nREPOSITORY',repo)
            for line in install_repo(repo,a.dry_run):
                if not line.startswith('KEEP '):print(' ',line)
        if a.hq:
            print('\nPORTFOLIO HQ',root)
            for line in install_hq(root,repos,a.dry_run): print(' ',line)
        print('\nDONE', 'dry-run, no files written' if a.dry_run else 'local files only, no pushes/deployments', '| repos',len(repos))
        return 0
    except (OSError,ValueError,UnicodeError) as e:
        print('ERROR:',e,file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
