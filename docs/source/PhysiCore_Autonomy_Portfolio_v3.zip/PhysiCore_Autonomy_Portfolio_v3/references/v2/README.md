# PhysiCore Codex Autonomy v2 — One executive agent, durable memory, targeted skills

This is a **repo overlay**, not a physics solver, an autonomous background service or a guarantee of customer readiness. It replaces the Claude-first seven-agent *execution model* with one proactive Codex executive. The seven engineering duties remain checklists/capabilities, not seven simultaneously billed AI contexts.

## Exactly what to do
1. Make a new branch in the **real application repository** and inspect existing root `AGENTS.md`, `CLAUDE.md`, `.claude/` and tests. Back up anything being replaced.
2. Copy this overlay's **contents** to the repository root. The overlay intentionally has an `AGENTS.md`; review conflicts and make this file the sole Codex instruction authority. Do not delete existing Claude files or production code automatically. If continuing to use Claude, reconcile its CLAUDE.md manually with the new rules.
3. Open that repository (root) in Codex and select an available Codex model appropriate to the task if available. Confirm you can access the code and run shell/tests. Cloud tasks require an appropriate Codex Cloud environment with the GitHub repository attached and configured permissions.
4. Run `python3 .physicore/tools/workflow.py doctor` then `python3 -m unittest discover -s tools/tests -v`.
5. Send the FIRST prompt: `Work. Inspect the actual repository first. Complete AUDIT-001, record tested facts in .physicore/ops/STATE.md, choose one customer-facing vertical slice, and implement one safe bounded improvement if time and permissions allow. Leave an investor digest. Do not merge or deploy.`
6. On later sessions, simply type **Work**. This causes another bounded run, not permanent self-running service. State persists only if Codex can save it back to the same repo/branch (commit/push if authorized). **Resume from the same continuity branch or an updated base that actually contains prior state changes**. Separate cloud tasks starting from unchanged main will not magically see a previous task's unmerged draft-PR state. Confirm changes survive cloud task resets.

## Files you should normally care about
- `AGENTS.md`: always-loaded compact mandate.
- `.physicore/ops/STRATEGY.md`: mission, customer wedge, success metrics.
- `.physicore/ops/STATE.md`: 1-page resume summary; most important for one-word continuation.
- `.physicore/ops/TASKS.json`: scored queue and actual statuses.
- `.physicore/ops/INVESTOR_DIGEST.md`: readable outcome, evidence, risks, next step.
- `.physicore/ops/WORKFLOW.md` and optional `.agents/skills/`: on-demand procedures.
- `.physicore/ops/SCIENTIFIC_GATES.md`: risk-based verification and validation.
- `.physicore/tools/workflow.py`: deterministic task selector/ledger; only stdlib, no paid API.

## Why this design saves usage
Only AGENTS.md is eagerly injected. Skills and policy documents are targeted; ordinary tasks require state, queue and relevant code. One implementation agent, one focused task, relevant tests, and handoff avoid repetitive discovery and unnecessary specialist calls. The scorer ranks tasks but **cannot replace engineering judgment** or measure token spend directly.

## What this does not do
- It cannot wake Codex in the background; schedule separately if desired and available.
- It cannot bypass permissions, buy compute, guarantee researcher access, or run a CFD solver absent from the environment.
- It cannot turn unreviewed calculations into experimentally validated physics.
- It has not inspected your application repository. Initial state correctly says UNKNOWN.

See `MIGRATION_AND_AUDIT.md` for gaps in the original Claude kit, `.physicore/ops/EFFICIENCY.md` for the controlled token-efficiency comparison, and `company/` for optional multi-repository CEO mode.
