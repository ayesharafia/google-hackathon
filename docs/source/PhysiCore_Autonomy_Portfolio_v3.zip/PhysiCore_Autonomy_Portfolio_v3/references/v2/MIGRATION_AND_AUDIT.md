# Review of the uploaded Claude sim-kit (2026-10-22)

## What was inspected
- Root AUTONOMY.md, PLAYBOOK.md and existing AGENTS.md; `sim-kit.zip` (41 ZIP entries).
- The ZIP contains governance files, templates, seven `.claude/agents/` role definitions and nine `.claude/commands/` definitions, but **no application source, real solver test outputs, benchmark datasets or executed evidence**. This kit cannot establish code maturity by itself.

## Strengths to keep
- Explicit GREEN/YELLOW/RED decision rights and the rule to park blocked decisions.
- Tests-before-implementation as a strong default when a meaningful oracle exists.
- Separation of implementation, verification, validation and explanation.
- Durable backlog, journal, approvals and plain-language reporting.

## Required fixes and precise reasons
1. **Provider mismatch:** `.claude/agents` and `.claude/commands` are Claude-specific; Codex reads root `AGENTS.md` and discovers Codex skills. Names in another tool's folders do not by themselves launch actual Codex specialist agents.
2. **Over-prescriptive subagents:** AUTONOMY routing always delegates several roles even for minor edits, adding context/coordination usage. Use one agent; optional specialist only for independently valuable tasks.
3. **Conflicting policy:** original CLAUDE.md and prior AGENTS.md differ in default run count, sign-off, claims and execution style. Reconcile rather than letting clients disagree.
4. **Scientist assumption:** assumes a human scientist exists, is available weekly, and can approve specs. Not established. Track actual reviewer and allow provisional reversible implementation without calling it validated.
5. **False scientific shortcuts:** PLAYBOOK says three yes/no answers mean "ship" and visual plot overlap indicates acceptance. Neither proves physical truth; a visually close plot can hide significant systematic error. A model may have no analytic solution or mesh. The L0→L6 ladder is not universal and L5 cross-code ≠ L6 experimental validity.
6. **Unjustified thresholds:** 0.1% imbalance is not universally correct; the initial T001 uses `<1e-6` on a "trivial mesh" without defined reference/test. Proposed tolerances require scientific justification, not default acceptance.
7. **Empty planning data:** ROADMAP has blank domain tables, priorities are `?`, and BACKLOG prescribes foundation tasks without inspecting real implementation. Need evidence-backed intake, one active wedge, true current status and reliable task dependencies.
8. **No mechanism for CEO work:** no live market scouting cadence, customer-decision definition, source/provenance log, commercial prioritization score, task picker or persisted resume snapshot. Added focused strategy and selector.
9. **High overhead:** AUTONOMY directs full-suite testing every start, constant multi-file rereads and up to 3 tasks per cycle. Use affected-suite-first testing and one bounded task with evidence.
10. **Safety and governance gaps:** explicit protections for flight-critical changes, cloud spend, irreversible changes, publishing customer claims, and draft-only PRs were incomplete/fragmented.
11. **No proof of operation:** role files and Markdown are only instructions. Track actual commands, exit codes, files, commit and benchmark source; distinguish PASS / FAIL / NOT RUN.
12. **Portability:** There is no actual always-on execution without scheduling and cloud environment, and the user's Plus allowance is limited. Do not imply that a Markdown file makes Codex run indefinitely.

## Mapping old files
- `CLAUDE.md` + previous `AGENTS.md` -> new authoritative root `AGENTS.md` for Codex.
- `AUTONOMY.md` + `.claude/agents/orchestrator.md` -> `.physicore/ops/WORKFLOW.md` and `physicore-work` skill.
- `PLAYBOOK.md` + `.claude/agents/*` -> strategic/technical policies plus optional focused skills.
- `ROADMAP.md` -> `.physicore/ops/STRATEGY.md` and `.physicore/ops/STATE.md` (evidence/goal separation).
- `BACKLOG.md` -> `.physicore/ops/TASKS.json` (scorable task queue, deterministic eligibility).
- `JOURNAL.md` -> `.physicore/ops/WORKLOG.md` and one-page `.physicore/ops/INVESTOR_DIGEST.md`.
- `VALIDATION.md` -> `.physicore/ops/SCIENTIFIC_GATES.md` and per-feature evidence records.
- `INBOX_*` and `DECISIONS.md` -> `.physicore/ops/APPROVALS.md` (retain historic logs in Git; do not silently destroy).

## Migration warning
This is not an in-place edit of a live repository. Do not copy this over code or existing instructions without checking conflicts. The old Claude files can coexist physically, but if used with Claude they should be reconciled with the new Codex authority. A multi-repo company needs one kit per repository, each with its own evidence-backed state, not a fictional globally shared repo state.
