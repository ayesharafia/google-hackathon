# Optional multi-repository mode

If PhysiCore operates four separate projects, install the main overlay in **each** actual code repository so the agent can always resume individual tasks. For investor-style delegation across all projects, maintain a small company HQ workspace holding a copy of `PORTFOLIO_TEMPLATE.md`, links to those repositories, and an HQ `AGENTS.md` saying "on Work, inspect portfolio summaries, choose one accessible repo, then execute that repo's own rules". Prefer a Git-backed portfolio file so state survives session resets. A normal single-repository Codex session cannot access arbitrary other projects merely because they are named here.

This optional folder is not activated by default, since cross-repository research on every run would waste usage. Start per-repository until the owner has verified the connections.
