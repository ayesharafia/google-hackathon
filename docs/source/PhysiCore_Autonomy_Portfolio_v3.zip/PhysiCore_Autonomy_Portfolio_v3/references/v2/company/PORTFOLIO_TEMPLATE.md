# Optional company-wide portfolio HQ (NOT YET CONNECTED)

Use this only if a single "Work" must choose **among several repositories**. Each application repository must maintain its own AGENTS.md, .physicore/ops/STATE.md and .physicore/ops/TASKS.json. Never treat this template as evidence of their actual state.

| Repository | Local/cloud location (verify) | Product wedge | Last verified milestone | Current business priority | Biggest evidence blocker |
|---|---|---|---|---|---|
| Drone | UNLINKED | UNKNOWN | UNKNOWN | UNDECIDED | Code audit needed |
| Thermal | UNLINKED | UNKNOWN | UNKNOWN | UNDECIDED | Code audit needed |
| Data center cooling | UNLINKED | UNKNOWN | UNKNOWN | UNDECIDED | Code audit needed |
| Battery | UNLINKED | UNKNOWN | UNKNOWN | UNDECIDED | Code audit needed |

## Company-level "Work" policy

1. The owner must first connect the real repositories and grant permissions in the current Codex environment. Do not invent local filesystem paths or GitHub access.
2. Read a one-page summary from each **accessible** repo (not every source file), compare near-term customer value, urgency, hard blockers, execution feasibility and risk.
3. Select one repo and one eligible task; open the target's AGENTS.md/STATE.md and perform its normal workflow. Prefer completing one vertical demo over spreading shallow commits across all domains.
4. Update that repo's state and this portfolio summary only when actual access and recorded evidence exist. If a repository is inaccessible, mark UNKNOWN and work on an accessible alternative.
5. One agent at a time is still the default. Company-wide choice does **not** require parallel agents or API expenses.

Company HQ is an optional *separate workspace/repository*. Copying this template into one application repo does not automatically grant access to sibling repos or create a scheduler.
