# PhysiCore Autonomy Portfolio v3: offline verification

Validation performed on temporary local Git repositories; **no actual Physicore company repository was modified** during package development.

The following six scenarios passed in individual or grouped `unittest` runs on 22 October 2026:

1. Installs in six separate Git repositories; creates HQ selector; respects existing `AGENTS.md` instructions; workflow doctor operates.
2. `--dry-run` reports actions without writing files.
3. Reinstallation is idempotent and preserves modified project policies, user-edited memory and skill files.
4. An audit cannot complete using a placeholder `STATE.md`; a real source inventory and an updated source-citing narrative are required.
5. A scoped implementation task remains blocked without actual non-kit file changes and an executed passing verification command; it then completes with recorded evidence.
6. A symlink collision stops unsafe installation instead of overwriting a linked file.

The archive is also checked with Python's `zipfile.testzip()`. Review results do not establish production security, numerical accuracy, customer-market fit, access to private repositories, or autonomous behavior outside an active Codex session.

To independently rerun all tests:

```bash
python3 -m unittest discover -s tests -v
```

**Important:** test infrastructure may take longer than the program logic when creating many temporary Git repositories; tests are local/offline and do not require API keys.
