#!/usr/bin/env python3
"""Read-only PhysiCore company portfolio chooser: actual accessible local Git repos only."""
from __future__ import annotations
import argparse,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
CFG=ROOT/'.physicore-hq/PORTFOLIO.json'
def load():return json.loads(CFG.read_text())['projects']
def summarize(p):
    repo=(ROOT/p['path']).resolve()
    if not repo.is_relative_to(ROOT.resolve()) or not (repo/'.git').exists():
        return {'name':p.get('name','unknown'),'path':p['path'],'status':'INACCESSIBLE','priority':p.get('priority',3)}
    tasks=repo/'.physicore/ops/TASKS.json'
    if not tasks.exists():return {'name':repo.name,'path':p['path'],'status':'NOT INSTALLED','priority':p.get('priority',3)}
    try:
        q=json.loads(tasks.read_text());done={t['id'] for t in q['tasks'] if t['status']=='done'}
        running=[t for t in q['tasks'] if t['status']=='in_progress']
        ready=[t for t in q['tasks'] if t['status']=='ready' and t['zone']=='green' and all(x in done for x in t['depends_on'])]
        ranked=sorted(running or ready,key=lambda t:(t.get('kind')!='regression',-t.get('priority',3),t['id']))
        next_=ranked[0] if ranked else None
        return {'name':p.get('name',repo.name),'path':p['path'],'status':'READY' if next_ else 'NEEDS TASK SCOPING','priority':p.get('priority',3),'next_id':next_['id'] if next_ else None,'next_title':next_['title'] if next_ else None,'task_priority':next_.get('priority',3) if next_ else 0}
    except (ValueError,KeyError,TypeError) as e:return {'name':repo.name,'path':p['path'],'status':'INVALID QUEUE','priority':p.get('priority',3),'error':str(e)}
def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['status','next']);args=p.parse_args()
    rows=[summarize(x) for x in load()]
    for row in rows: print(f"{row['name']}: {row['status']}; portfolio priority={row['priority']}; next={row.get('next_id','NONE')}; path={row['path']}")
    if args.command=='next':
        ready=[r for r in rows if r['status']=='READY']
        if ready:
            best=sorted(ready,key=lambda r:(-r['priority'],-r['task_priority'],r['path']))[0]
            print(f"SUGGESTED {best['name']} :: {best['next_id']} :: {best['next_title']}")
        else:print('NO READY PROJECTS. Audit/scoping needed in accessible repos. Do not invent completed work.')
if __name__=='__main__': main()
