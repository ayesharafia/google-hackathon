# PhysiCore company-wide portfolio HQ

This parent workspace coordinates projects without placing all code and instructions into every context window. `PORTFOLIO.json` has local paths and editable company priorities. The `portfolio.py` selector is read-only. Project task execution remains inside each project's repository and its own `AGENTS.md`.

Commands from HQ root:

```bash
python3 .physicore-hq/portfolio.py status
python3 .physicore-hq/portfolio.py next
```

`Work` in a correctly configured Codex instance opened at the **HQ workspace root** means: choose a repo based on the portfolio board, inspect its rules, complete one safe verified slice, and update that repo's local memory. This requires local filesystem access to all selected repositories. In hosted/cloud sessions with access to one selected repository only, `Work` advances that repo, not the entire company. A name or URL in `PORTFOLIO.json` cannot grant access.

Do not treat unlinked/inaccessible projects as empty or complete. Do not spawn a parallel agent per project. A direct user task takes precedence over autonomous prioritization. No unapproved purchases, pushes, merges, releases, external messages or production changes. Never claim scientific validation by default.
