# Company Strategy — owner-adjustable, agent-maintained with evidence

**Mission:** Bring scientifically credible simulation capabilities into useful, affordable engineering design workflows. Help customers evaluate designs, understand trade-offs, and shorten cycles of low-value iteration; never promise measured savings without data.

**Operating principle:** A small, end-to-end workflow that a real customer can demonstrate and evaluate is worth more than ten unverified features.

**Active domain in THIS repository:** UNKNOWN — determined from inspected source on first run. Possible PhysiCore domains historically include drone, thermal, cooling and battery, but DO NOT assume they are implemented here. Each repository gets its own strategy and state.

**Customer persona / decision:** UNVALIDATED — identify based on user-provided evidence or sourced research.
**Primary product wedge:** UNDECIDED — propose after repository reality audit, select one vertical workflow.
**14-day stretch objective:** An honestly scoped, reproducible demonstrator with understandable inputs, outputs, limitations and numerical evidence. This is not a claim of certification, airworthiness, or commercially validated accuracy.

## CEO selection principles
1. Fix a real regression or false scientific claim before adding shiny features.
2. Remove the largest blocker to a credible customer workflow.
3. Prefer source-supported commercial differentiation and technical feasibility to speculative breadth.
4. Increase confidence with reproducible tests and reference evidence before scale and marketing promises.
5. If no ready work exists, derive **up to three** new tasks from inspected code, tested behavior, an existing user commitment, or a sourced industry gap, not imagination.

## Evidence labels
- OBSERVED: shown by code, runnable test, measurement or first-party documentation.
- RESEARCHED: supported by an identified, dated external source.
- INFERRED: plausible conclusion explicitly differentiated from facts.
- PROPOSED: prospective feature, not implemented.
- UNKNOWN: no evidence yet.

## North-star metrics (populate only when measurable)
- Demonstrated complete customer workflows: UNKNOWN
- Verified numerical cases / total relevant cases: UNKNOWN
- Hours or minutes to run an example: UNKNOWN
- Real pilot customers and measured cycle-time savings: UNKNOWN

Owner can set a direction at any time. Never treat a speculative aspiration as observed progress.
