# PhysiCore project handoff (evidence-backed, keep under ~80 lines)

- Last verified run: NONE
- Repo and current branch: UNKNOWN, inspect Git
- Domain and solver: UNKNOWN, do not assume CFD/thermal/drone
- Current user/workflow: UNKNOWN, select via audit
- Product priority: complete real code audit; do not promise scientific validity
- Demonstrated capabilities: NONE CONFIRMED BY THIS KIT
- Scientific confidence: UNVERIFIED until project-specific evidence exists
- Current task: AUDIT-001
- Most important blocker: source repository not yet inspected by Codex
- Tests executed: NONE by installer
- Next action: run v3 workflow audit, scope one specific vertical slice, implement/tests
- Source of truth: Git code/tests, test proof records, qualified domain review
