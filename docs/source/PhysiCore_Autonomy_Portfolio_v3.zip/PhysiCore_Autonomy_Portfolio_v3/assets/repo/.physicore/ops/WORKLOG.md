# Evidence log

This file is appended by `.physicore/tools/workflow.py complete` after a task attempt; add manually verified test commands, diff/commit/PR links and scientific limitations in the linked evidence artifacts. Entries are historical, so read only recent lines during ordinary runs.
