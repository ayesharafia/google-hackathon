# PhysiCore project decisions requiring human or qualified scientific approval

- No specific approvals recorded yet. Do not infer approval from empty file.
- Ask for approval only for scientific models/claims needing an expert, irreversible security/data changes, paid tools/compute, production deployments, external contacts/communications, or flight/safety-critical work.
- Record each request as: date; project; decision owner; choices; recommended safe option; risks; evidence; what work remains safe to proceed with; result and reference.
- A normal local code/test/documentation edit inside granted tool permissions needs no repeated user prompt.
