from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import time
import io
import contextlib
from types import SimpleNamespace

KIT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('pcinstall',KIT/'install.py')
install=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(install)

def invoke(*argv,cwd=None):
    t=time.monotonic()
    out=subprocess.run([sys.executable,*[str(x) for x in argv]],cwd=cwd,capture_output=True,text=True)
    if __import__("os").environ.get("TRACE_TEST"): print(f"[trace] {str(argv)[:110]} took {time.monotonic()-t:.2f}s RC {out.returncode}", flush=True)
    return out

def new_repo(path:Path,with_agents=False):
    path.mkdir(parents=True)
    subprocess.run(['git','init','-q',str(path)],check=True)
    subprocess.run(['git','-C',str(path),'config','user.email','local@example.invalid'],check=True)
    subprocess.run(['git','-C',str(path),'config','user.name','Test Agent'],check=True)
    (path/'README.md').write_text('# Sample Physicore project\n\nThis project has real application code and evidence.\n')
    (path/'app.py').write_text('def add(a,b): return a+b\n')
    if with_agents:(path/'AGENTS.md').write_text('# Existing project policy\nDo not hide numeric errors or suppress NaNs.\n')
    subprocess.run(['git','-C',str(path),'add','.'],check=True)
    subprocess.run(['git','-C',str(path),'commit','-qm','baseline'],check=True)

class PackageTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.repos=[self.root/f'project{i}' for i in range(6)]
        for i,r in enumerate(self.repos):new_repo(r,i==0)
    def do_install(self):
        p=invoke(KIT/'install.py','install','--workspace',self.root,'--all','--hq')
        self.assertEqual(p.returncode,0,p.stdout+'\n'+p.stderr)
        return p
    def work(self,repo,*args):
        script=repo/'.physicore/tools/workflow.py'
        name='pcworkflow_'+repo.name
        if not hasattr(self,'_mods'):self._mods={}
        if name not in self._mods:
            spec=importlib.util.spec_from_file_location(name,script)
            mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
            self._mods[name]=mod
        mod=self._mods[name]
        out=io.StringIO();err=io.StringIO()
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
            rc=mod.main([str(x) for x in args])
        return SimpleNamespace(returncode=rc,stdout=out.getvalue(),stderr=err.getvalue())
    def test_six_repository_install_and_hq_scan(self):
        x=invoke(KIT/'install.py','scan','--workspace',self.root)
        self.assertEqual(x.returncode,0,x.stderr)
        self.assertIn('TOTAL 6',x.stdout)
        self.do_install()
        for r in self.repos:
            if __import__("os").environ.get("TRACE_TEST"):print("checking",r.name,flush=True)
            self.assertTrue((r/'.physicore/tools/workflow.py').is_file())
            self.assertTrue((r/'.agents/skills/physicore-work/SKILL.md').is_file())
            self.assertIn('PHYSICORE AUTONOMY V3 START',(r/'AGENTS.md').read_text())
            self.assertEqual(self.work(r,'doctor').returncode,0)
        self.assertIn('Do not hide numeric errors',(self.repos[0]/'AGENTS.md').read_text())
        self.assertIn('project0', (self.root/'.physicore-hq/PORTFOLIO.json').read_text())
        p=invoke(self.root/'.physicore-hq/portfolio.py','next',cwd=self.root)
        self.assertIn('SUGGESTED',p.stdout)
    def test_dry_run_no_mutation(self):
        p=invoke(KIT/'install.py','install','--workspace',self.root,'--all','--hq','--dry-run')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertFalse((self.repos[0]/'.physicore').exists())
        self.assertFalse((self.root/'.physicore-hq').exists())
    def test_repeat_preserves_dynamic_and_unmanaged_files(self):
        self.do_install();r=self.repos[0]
        agents=(r/'AGENTS.md').read_text()
        (r/'.physicore/ops/STATE.md').write_text('Custom working memory kept through upgrades\n')
        p=r/'.physicore/ops/SCIENTIFIC_GATES.md';p.write_text('User customization\n')
        (r/'.agents/skills/physicore-work/SKILL.md').write_text('Custom skill override\n')
        self.do_install()
        self.assertEqual(agents,(r/'AGENTS.md').read_text())
        self.assertEqual((r/'.physicore/ops/STATE.md').read_text(),'Custom working memory kept through upgrades\n')
        self.assertEqual(p.read_text(),'User customization\n')
        self.assertEqual((r/'.agents/skills/physicore-work/SKILL.md').read_text(),'Custom skill override\n')
    def test_audit_refuses_placeholder_then_accepts_documented_source(self):
        self.do_install();r=self.repos[0]
        self.assertEqual(self.work(r,'start','AUDIT-001').returncode,0)
        audit=self.work(r,'audit','AUDIT-001');self.assertEqual(audit.returncode,0,audit.stderr)
        proof=self.work(r,'proof','AUDIT-001','--summary','Inspected real source and test structure');self.assertEqual(proof.returncode,0,proof.stderr)
        comp=self.work(r,'complete','AUDIT-001','--evidence','.physicore/evidence/AUDIT-001-completion.json','--notes','audit')
        self.assertNotEqual(comp.returncode,0)
        self.assertIn('placeholders',comp.stderr)
        state=r/'.physicore/ops/STATE.md'
        state.write_text('# Audit result\nLast verified run: tested just now\nObserved source: app.py\nDemonstrated capabilities: implementation of add(), with no physical validity claim.\n')
        comp=self.work(r,'complete','AUDIT-001','--evidence','.physicore/evidence/AUDIT-001-completion.json','--notes','audit')
        self.assertEqual(comp.returncode,0,comp.stderr)
        q=json.loads((r/'.physicore/ops/TASKS.json').read_text())
        self.assertEqual(q['tasks'][0]['status'],'done')
        self.assertEqual(q['tasks'][1]['status'],'candidate')
    def test_scoping_prevents_premature_promotion_and_requires_actual_test(self):
        self.do_install();r=self.repos[0]
        self.work(r,'start','AUDIT-001')
        state=r/'.physicore/ops/STATE.md';state.write_text('Reviewed app.py and README.md\nLast verified run: today\nDemonstrated capabilities: add() works\n')
        self.work(r,'proof','AUDIT-001','--summary','Observed code, source and tests')
        self.assertEqual(self.work(r,'complete','AUDIT-001','--evidence','.physicore/evidence/AUDIT-001-completion.json','--notes','audit').returncode,0)
        p=self.work(r,'scope','SLICE-001','--title','Improve summation correctness','--acceptance','Add testable support for three addends, assert output 6 and preserve 2-argument case','--source','.physicore/ops/STATE.md')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('NEXT SLICE-001',self.work(r,'next').stdout)
        self.assertEqual(self.work(r,'start','SLICE-001').returncode,0)
        # a placeholder file must not permit successful completion
        proof=self.work(r,'proof','SLICE-001','--summary','No code changed yet')
        self.assertNotEqual(proof.returncode,0);self.assertIn('No new non-kit changes',proof.stderr)
        (r/'app.py').write_text('def add(a,b,c=0): return a+b+c\n')
        proof=self.work(r,'proof','SLICE-001','--summary','Code changed but no test executed')
        self.assertNotEqual(proof.returncode,0);self.assertIn('successful local verification',proof.stderr)
        check=self.work(r,'check','SLICE-001','--',sys.executable,'-c','assert __import__("app").add(1,2,3)==6')
        # Allowlist uses python/python3; interpreter path is not allowed by design
        self.assertNotEqual(check.returncode,0)
        check=self.work(r,'check','SLICE-001','--','python3','-c','assert __import__("app").add(1,2,3)==6')
        self.assertEqual(check.returncode,0,check.stderr)
        import re
        relative=re.search(r'\.physicore/evidence/[^\s]+\.json',check.stdout).group(0)
        proof=self.work(r,'proof','SLICE-001','--summary','Added 3-argument summation, verified both paths','--test',relative)
        self.assertEqual(proof.returncode,0,proof.stderr)
        comp=self.work(r,'complete','SLICE-001','--evidence','.physicore/evidence/SLICE-001-completion.json','--notes','One reproducible passing test')
        self.assertEqual(comp.returncode,0,comp.stderr)
        q=json.loads((r/'.physicore/ops/TASKS.json').read_text());self.assertEqual(q['tasks'][1]['status'],'done')
    def test_symlink_collision_not_overwritten(self):
        self.do_install()
        r=self.repos[0]
        bad=r/'.physicore/ops/STATE.md';bad.unlink()
        bad.symlink_to(r/'README.md')
        p=invoke(KIT/'install.py','install','--workspace',self.root,'--repo',r)
        self.assertNotEqual(p.returncode,0)
        self.assertEqual((r/'README.md').read_text().splitlines()[0],'# Sample Physicore project')

if __name__=='__main__':unittest.main()
