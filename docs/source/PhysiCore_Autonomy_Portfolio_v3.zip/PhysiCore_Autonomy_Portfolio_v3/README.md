# PhysiCore Autonomy Portfolio v3

A substantially hardened, generic successor to `PhysiCore_Codex_Autonomy_v2.zip` for **multiple active repositories**.

## Main improvements over v2

| Item | v3 behavior |
| --- | --- |
| Company scope | Local multi-repo scan, safe repeatable install, HQ portfolio board and read-only picker |
| Existing instructions | Managed, reversible `AGENTS.md` section; never clobber project rules, `CLAUDE.md`, existing code |
| Portable path | `.physicore/` per repo, no assumption project is CFD/drone/thermal |
| Status credibility | Audit must inventory real source and update an evidence-backed state report |
| Work completion | Implementation completion must tie to observable changed app files and recorded successful verification |
| Backlog | `scope` / `add` / `refresh` promote a candidate once dependencies and a nonplaceholder spec are present |
| Context efficiency | Root `AGENTS.md` short; deeper science/product/market policy loaded only when needed |
| Controls | No paid API/HPC, automatic merges, emails, deployment or flight-critical changes; preserves stricter existing rules |
| Re-installation | Incremental, SHA-tracked managed files, dynamic working memory preserved, conflicts reported |
| Existing v2 continuity | Legacy `ops/STATE.md`, `ops/TASKS.json` etc copied to `.physicore/legacy/` when present, originals untouched; agents reconcile without pretending the old evidence schema is valid |
| Offline runtime | Standard-library Python; no background daemon, API key or broker server |

## Contents

- `START_HERE.md`: first file ChatGPT/Codex should read, with exact install instructions.
- `MASTER_DIRECTIVE.md`: full one-time agent setup and subsequent Work behavior.
- `install.py`: safe multi-project installer, scanner and HQ creator.
- `assets/repo/`: per-repo `.physicore/` harness and three opt-in agent skills.
- `assets/hq/`: portfolio selector that reads *actual accessible* project task ledgers.
- `references/v2/`: preserved original v2 explanation, audit and company context, not automatically injected.
- `tests/`: offline installer and workflow tests. Run `python3 -m unittest discover -s tests -v` from the unpacked kit folder.

## Command reference

```bash
python3 install.py scan --workspace /path/to/physicore-parent
python3 install.py install --workspace /path/to/physicore-parent --all --hq --dry-run
python3 install.py install --workspace /path/to/physicore-parent --all --hq
python3 -m unittest discover -s tests -v
```

Never run `--all` in a workspace also holding unrelated repos. Use repeated `--repo` instead.

### After installing

Inside an actual project repo:

```bash
python3 .physicore/tools/workflow.py doctor
python3 .physicore/tools/workflow.py next
```

Inside portfolio HQ:

```bash
python3 .physicore-hq/portfolio.py status
python3 .physicore-hq/portfolio.py next
```

## Truthfulness and restrictions

This package is an agent workflow and local scripts, **not** an autonomous continuously running CEO, scientific solver, plug-and-play multi-repository GitHub authorization, a model subscription, or a proof of engineering correctness. It does not provide independent scientific review. It does not change your repositories merely by being attached to a conversation. A supported writable Codex environment must unpack and run `install.py` in the right directory.

Developer reference: [Codex AGENTS.md](https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex) and [lean instruction guidance](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra).
