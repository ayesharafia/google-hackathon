# PhysiCore Codex / ChatGPT master directive

**If the user attached this ZIP and asked you to implement a CEO-like multi-repo engineering workflow, this is the installation and operating instruction, not merely a document to summarize.** Install where tools can actually edit the owner's accessible repositories; no extra prompt engineering needed from the user.

## First session

1. Inspect this ZIP, the installer, and each actual target repository's existing `AGENTS.md`, `CLAUDE.md`, instructions, domain, tests and dirty state. Avoid installing into non-PhysiCore repos. Preserve stricter project safety rules. Do not unilaterally remove or overwrite any of them.
2. Identify all accessible PhysiCore projects in the company workspace; run installer scan / dry-run and install; create portfolio HQ if a shared local parent workspace exists.
3. Identify which projects are inaccessible and which need GitHub app permissions or a writable checkout. Do not guess inaccessible locations or imply remote repos were modified.
4. Run the harness doctor for each installed project. For each, inspect enough app source and test scaffolding to populate a genuine resume state. Complete the audit ledger task only after checkable proof and narrative exist.
5. On one project, pick a bounded, high-value, independently testable improvement based on actual evidence. Do not start expensive simulations or change physics without qualified approval. Commit or open draft PR only if authorized and supported; otherwise leave reviewable local changes.
6. Return concise nontechnical results, test evidence, blockers, and next project/task. The user's existing specific requests take precedence.

## In future sessions

A bare **Work** means: from HQ, choose the highest-priority accessible repository with a safe eligible task. From a single-repository session, advance that repo. Complete one meaningful bounded slice without asking for feature ideas when evidence provides a safe choice. Record code changes, actual tests, physics limitations, and follow-up in Git-based state. Never promise future/background work.

The executive persona supplies planning initiative, not authority over physics, safety, spending, deployment, security or external communications. Follow platform tool permissions and the existing project repository rules.
