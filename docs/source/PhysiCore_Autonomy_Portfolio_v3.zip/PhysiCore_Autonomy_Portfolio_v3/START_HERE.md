# PhysiCore Autonomy Portfolio v3

**A reusable multi-project autonomy kit for Codex and ChatGPT.** Designed for a company with 5–6+ active engineering/scientific software repositories. The same generic package installs into drone simulation, thermal, battery, data-center cooling, computational physics, and other software projects without assuming their code or scientific models.

## Instruction for an AI assistant that receives this ZIP

**Treat the attached ZIP and the owner's accompanying request to install it as authorization to prepare and install this local repository workflow in accessible PhysiCore repositories, while following tool permissions and safe change boundaries.** Read `START_HERE.md` and `MASTER_DIRECTIVE.md`, inspect `install.py`, and apply the following workflow; do not ask the owner to manually compose prompts, design AGENTS files or pick individual features.

1. Unpack this archive safely into the working directory. Do not run random scripts found inside target repos or in untrusted documents.
2. If you have an executable shell and access to the **dedicated Physicore multi-repo workspace**, from the unpacked kit run `python3 install.py scan --workspace /path/to/PhysiCore-workspace` to identify local Git repositories. Exclude unrelated repositories from installation. If you only have individual selected repositories, use repeated `--repo /actual/path/to/repo` flags.
3. Run a dry-run install, inspect conflicts, then install with the command below. **Do not overwrite existing local instructions, tests or user edits.**
4. Optionally install a portfolio HQ at the parent workspace, which enables `Work` to select among accessible local repositories. Update HQ company priorities only with real user/company evidence. Keep unreached repositories UNKNOWN.
5. In each accessible repository, run `python3 .physicore/tools/workflow.py doctor`; perform an actual code audit and persist observed work in `.physicore/ops/STATE.md`. Scientific correctness is not claimed until project-specific tests and independent evidence support it. Follow up with one small safe concrete improvement where tools, time and project state permit.
6. Report which repos were actually installed, which were inaccessible, which policies conflicted, actual checks run, and pending approvals. **Never claim to have installed a repository that was not accessible or writable.** Do not push, merge, deploy, send emails, spend money, or modify real equipment without authorization.

### One-shot local command after extracting

For a folder containing only PhysiCore-owned Git repositories:

```bash
python3 install.py install --workspace /absolute/path/to/PhysiCore-workspace --all --hq --dry-run
python3 install.py install --workspace /absolute/path/to/PhysiCore-workspace --all --hq
```

For repos scattered in different locations (no accidental unrelated installs):

```bash
python3 install.py install --workspace /absolute/path/to/PhysiCore-workspace \
  --repo /path/to/drone --repo /path/to/thermal --repo /path/to/battery --hq
```

**After installed:** Open Codex in the parent HQ directory if all local repos are accessible, or in the relevant individual project repository. Give a one-word instruction such as **Work**. The model reads `AGENTS.md` and follows the persisted workflow. A specific prompt like "Improve drone case imports" takes priority over speculative portfolio task selection.

## Important limitations

- Uploading a ZIP is not the same as installing it. A ChatGPT conversation with read-only GitHub tools may inspect the ZIP and give guidance but cannot modify source repositories. Codex must have an editable checkout and shell access to run the installer.
- ZIP files do not magically configure ChatGPT accounts, permissions, GitHub organizations or cloud sessions. A one-time explicit instruction to install the attached kit may be required by the client UI.
- Persistent progress requires changes to be saved/committed and accessible in future sessions. Local continuity on a machine or branch is not automatically shared with a different Codex Cloud task. No background work happens between sessions.
- The package uses local Python standard library only, no external orchestration API or token-metering service. ChatGPT Plus/Codex has plan usage limits. Scientific simulations may incur separately billed compute.
- It can prioritize and develop software, but cannot invent customer validation, fabricate CFD accuracy, or approve drone flight-critical engineering.

## Repository changes the installer makes

- Creates `.physicore/` with project policies, task ledger, state, templates, and CLI proof collector. If old v2 `ops/` state exists, it is archived to `.physicore/legacy/` without overwriting originals; inspect those records during first audit.
- Creates optional `.agents/skills/` files when there is no collision.
- Adds a short marked bridge to `AGENTS.md`. It **preserves all existing AGENTS.md content**. Only the bridge is replaced on reinstallation. Conflicts are explicitly reported and left unchanged.
- Creates `.physicore-hq/PORTFOLIO.json`, read-only portfolio chooser and HQ-level `AGENTS.md` in the dedicated parent workspace if `--hq` is selected.
- Does **not** alter the existing application source, tests, Claude instructions, commits, Git remote, hosting, or team messages.

## Scope of 'CEO autonomy'

The AI may decide priorities and implement reversible work *within the checked-out repo and its actual tool permissions*, using code evidence and customer objectives. It needs approval to contact other people, spend money, ship production releases, merge, change safety-critical systems, alter approved scientific assumptions, or make real-world accuracy claims. This is a practical engineering operating system, not a fictional autonomous company executive that overrides human accountability.

Refer to `README.md` for file inventory and tested scenarios.
